from django.contrib import admin
from .models import Pelicula, Director

admin.site.register(Pelicula)
admin.site.register(Director)
